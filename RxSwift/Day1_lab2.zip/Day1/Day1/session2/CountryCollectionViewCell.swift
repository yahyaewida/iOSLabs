//
//  CountryCollectionViewCell.swift
//  Day1
//
//  Created by Yahya Ewida on 4/23/20.
//  Copyright © 2020 Yahya Ewida. All rights reserved.
//

import UIKit

class CountryCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak internal var countryNameLabel: UILabel!

    @IBOutlet weak internal var countryCodeLabel: UILabel!
}
