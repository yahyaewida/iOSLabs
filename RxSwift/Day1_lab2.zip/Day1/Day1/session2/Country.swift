//
//  Country.swift
//  Day1
//
//  Created by Yahya Ewida on 4/23/20.
//  Copyright © 2020 Yahya Ewida. All rights reserved.
//

import Foundation


struct Country : Decodable{
    var name : String
    var code : String
    
    init(name: String, code: String) {
       self.name = name
       self.code = code
    }


}
