//
//  CollectionViewController.swift
//  Day1
//
//  Created by Yahya Ewida on 4/23/20.
//  Copyright © 2020 Yahya Ewida. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

class CollectionViewController: UIViewController {

    @IBOutlet weak private var countryCollectionView: UICollectionView!
    
    private var disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        prepareCollectionViewData()
    }
    
    private func prepareData() -> [Country]{

       if  let path = Bundle.main.path(forResource: "Countries", ofType: "plist"),
                    let xml = FileManager.default.contents(atPath: path),
                    let countries = try? PropertyListDecoder().decode([Country].self, from: xml){
                    return countries
                    
        }else{
            return [Country]()
        }
       

    }
    
    private func prepareCollectionViewData(){
        let observable = Observable<[Country]>.from(optional: prepareData())
            .subscribeOn(ConcurrentDispatchQueueScheduler.init(qos: .background))
            .observeOn(ConcurrentMainScheduler.instance)
        observable.bind(to: countryCollectionView.rx.items(cellIdentifier: "cell", cellType: CountryCollectionViewCell.self)){
            (index , country , cell) in
            cell.countryNameLabel.text = country.name
            cell.countryCodeLabel.text = country.code
        }.disposed(by: disposeBag)
        
    }
    

  

}
