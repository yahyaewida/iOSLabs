//
//  ViewController.swift
//  Day1
//
//  Created by Yahya Ewida on 4/23/20.
//  Copyright © 2020 Yahya Ewida. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

class ViewController: UIViewController {

    //Outlets
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var sliderLabel: UILabel!
    @IBOutlet weak var segmentControl: UISegmentedControl!
    @IBOutlet weak var segmentLabel: UILabel!
    
    
    //Variables
    let disposeBag = DisposeBag()
    
    
    
    //Functions
    override func viewDidLoad() {
        super.viewDidLoad()
        sliderObserver()
        segmentObserver()
       
    }
    
    private func sliderObserver(){
       slider.rx.value.subscribe( onNext: {(value) in
           
           self.sliderLabel.text = String(value)
       },
       onError: { (error) in
           print(error)
       }).disposed(by: disposeBag)
       
    }
    
    private func segmentObserver(){
        segmentControl.rx.selectedSegmentIndex.subscribe(onNext: {(index) in
            self.segmentLabel.text = self.segmentControl.titleForSegment(at: index)
        },
        onError: { (error) in
            print(error)
        }).disposed(by: disposeBag)
    }
    
    
  
}

