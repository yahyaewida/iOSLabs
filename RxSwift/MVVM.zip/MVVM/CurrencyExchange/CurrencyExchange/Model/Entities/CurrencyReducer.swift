//
//  CurrencyReducer.swift
//  CurrencyExchange
//
//  Created by Yahya Ewida on 4/23/20.
//  Copyright © 2020 Yahya Ewida. All rights reserved.
//

import Foundation

struct CurrencyReducer{
    var currencyName : String
    var currencyValue : Double
}
