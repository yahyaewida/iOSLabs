//
//  Constants.swift
//  CurrencyExchange
//
//  Created by Yahya Ewida on 4/23/20.
//  Copyright © 2020 Yahya Ewida. All rights reserved.
//

import Foundation


let apiURL = "https://api.exchangeratesapi.io/latest"
let currencyCollectionViewCellName = "cell"
