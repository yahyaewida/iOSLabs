//
//  CustomView.swift
//  test3
//
//  Created by Yahya Ewida on 4/8/20.
//  Copyright © 2020 Yahya Ewida. All rights reserved.
//

import UIKit

class CustomView: UIView {

    @IBOutlet weak var label2: UILabel!
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

    @IBAction func testAction(_ sender: Any) {
        print("test")
    }
    @IBAction func button2Action(_ sender: Any) {
        label2.text = "button clicked"
        print("from nib file")
    }
}
