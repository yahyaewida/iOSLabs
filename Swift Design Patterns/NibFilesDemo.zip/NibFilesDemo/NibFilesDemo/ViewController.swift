//
//  ViewController.swift
//  test3
//
//  Created by Yahya Ewida on 4/6/20.
//  Copyright © 2020 Yahya Ewida. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        if let customView: CustomView = Bundle.main.loadNibNamed("CustomView", owner: self, options: nil)?.first as? CustomView {
            
            self.view.addSubview(customView)
            
        }
    }
    @IBAction func actionTest(_ sender: Any) {
        print("test")
    }
    
}

