//
//  TableViewExtension.swift
//  MovieList
//
//  Created by Esraa Hassan on 3/26/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

import UIKit
import CoreData
extension TableViewController{
    
    
    
    func initializeJsonMovies() {
        
        let url = URL(string: "https://api.androidhive.info/json/movies.json")
        let urlRequest = URLRequest(url: url!)
        let session = URLSession(configuration: .default)
        session.dataTask(with: urlRequest) { (data, response, error) in
            do{
                var json = try JSONSerialization.jsonObject(with: data!, options: []) as! Array<Dictionary<String,Any>>
                
                
                for index in 0...json.count-1{
                    let dictionary = json[index]
                    var genere=""
                    let genereArray = dictionary["genre"] as! NSArray
                    for genereIndex in 0...genereArray.count-1{
                        genere.append(genereArray[genereIndex] as! String)
                        genere.append(" , ")
                    }
                    
                    self.moviesArray.append(Movie(mTitle: dictionary["title"] as! String, mImage: dictionary["image"] as! String, mrating: (dictionary["rating"] as? NSNumber)?.floatValue ?? 0  , mReleaseYear: dictionary["releaseYear"] as! Int, mGenre: genere))
                    
                }
                
                if self.moviesArray.count > 0{
                    CoreDataHandler.getCoreHandlerInstance().insertInWebserviceMovies(arrayOfMovies: self.moviesArray)
                }
                
                 self.remoteMoviesFromCache = CoreDataHandler.getCoreHandlerInstance().getWebserviceMovies()
                
                DispatchQueue.main.async {
                    print("data fetched from remote server")
                    self.tableView.reloadData()                    
                }
               
            }catch{
                print("error happened")
            }
            }.resume()
        
        
    }
    
    
    func insertInLocalMovies(movie movieValue:Movie) {
        let managedContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        let entity = NSEntityDescription.entity(forEntityName: "LocalMovies", in: managedContext)
        
        let movie = NSManagedObject(entity: entity!, insertInto: managedContext)
        
        movie.setValue(movieValue.title, forKey: "title")
        movie.setValue(movieValue.image, forKey: "imagePath")
        movie.setValue(movieValue.genre, forKey: "genre")
        movie.setValue(movieValue.rating, forKey: "rating")
        movie.setValue(movieValue.releaseYear, forKey: "releaseYear")
        
        do{
            try managedContext.save()
        }
        catch{
            print("error in insertInLocalMovies")
        }
    }
    
}
