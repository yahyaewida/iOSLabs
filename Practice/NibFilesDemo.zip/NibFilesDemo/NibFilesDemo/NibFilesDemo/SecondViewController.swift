//
//  SecondViewController.swift
//  test3
//
//  Created by Yahya Ewida on 4/8/20.
//  Copyright © 2020 Yahya Ewida. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if let customView: CustomView = Bundle.main.loadNibNamed("CustomView", owner: self, options: nil)?.first as? CustomView {
            
            self.view.addSubview(customView)
            
        }
        
    }
    



}
