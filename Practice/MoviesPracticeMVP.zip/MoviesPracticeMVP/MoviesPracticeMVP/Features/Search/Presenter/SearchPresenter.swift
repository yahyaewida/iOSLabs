//
//  SearchPresenter.swift
//  MoviesPracticeMVP
//
//  Created by Esraa Hassan on 4/12/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

import Foundation

class SearchPresenter{
    
}
