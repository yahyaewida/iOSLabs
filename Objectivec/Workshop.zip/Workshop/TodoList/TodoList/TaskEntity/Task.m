//
//  Task.m
//  TodoList
//
//  Created by Esraa Hassan on 3/22/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

#import "Task.h"

@implementation Task

- (void)encodeWithCoder:(NSCoder *)coder{
    [coder encodeInteger:_taskId forKey:@"id"];
    [coder encodeObject:_taskName forKey:@"name"];
    [coder encodeObject:_priority forKey:@"priority"];
    [coder encodeObject:_taskDescription forKey:@"description"];
    [coder encodeObject:_taskCreationDate forKey:@"date"];
    [coder encodeObject:_status forKey:@"status"];
    
}

-(instancetype)initWithCoder:(NSCoder*) decoder{
    _taskId = [decoder decodeIntForKey:@"id"];
    _taskName = [decoder decodeObjectForKey:@"name"];
    _priority = [decoder decodeObjectForKey:@"priority"];
    _taskDescription = [decoder decodeObjectForKey:@"description"];
    _taskCreationDate = [decoder decodeObjectForKey:@"date"];
    _status = [decoder decodeObjectForKey:@"status"];
    return self;
}

@end
