//
//  Task.h
//  TodoList
//
//  Created by Esraa Hassan on 3/22/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Task : NSObject
@property int taskId;
@property NSString* taskName;
@property NSString* taskDescription;
@property NSDate* taskCreationDate;
@property NSString* priority;
@property NSString* status;



@end


