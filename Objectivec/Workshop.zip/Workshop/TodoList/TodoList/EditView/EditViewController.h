//
//  EditViewController.h
//  TodoList
//
//  Created by Esraa Hassan on 3/23/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Task.h"
#import "TableViewUpdateProtocol.h"
#import "ViewController.h"
#import "DetailsViewController.h"

@interface EditViewController : UIViewController<UIAlertViewDelegate>


@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentControl;
@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UITextField *descriptionTextField;
@property (weak, nonatomic) IBOutlet UINavigationBar *navagationBar;
@property (weak, nonatomic) IBOutlet UISegmentedControl *statusSegmentControl;
- (IBAction)saveButtonAction:(id)sender;
- (IBAction)cancelButtonAction:(id)sender;

@property id<TableViewUpdateProtocol> tableViewController;
@property Task* task;


@end
