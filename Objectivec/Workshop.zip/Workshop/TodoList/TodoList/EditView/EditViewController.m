//
//  EditViewController.m
//  TodoList
//
//  Created by Esraa Hassan on 3/23/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

#import "EditViewController.h"
#import "UserDefaultsObject.h"
@interface EditViewController ()

@end

@implementation EditViewController{
    UIAlertView *confirmationAlertView;
NSArray* priorties;
NSArray* statuses;
    NSUserDefaults* userDefaults2;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
   
    confirmationAlertView = [[UIAlertView alloc] initWithTitle:@"Confirmation" message:@"Do you want to save changes" delegate:self cancelButtonTitle:nil otherButtonTitles:@"Yes",@"No",nil];
    
    userDefaults2 = [UserDefaultsObject getUserDefaults];
    
    statuses =@[@"todo",@"inProgress",@"done"];
    priorties = @[@"1",@"2",@"3"];
    
    [_statusSegmentControl setSelectedSegmentIndex:0];
    
    _nameTextField.text = _task.taskName;
    _descriptionTextField.text = _task.taskDescription;
    
    if([_task.priority isEqualToString:@"1"])
         [_segmentControl setSelectedSegmentIndex:0];
    
    else if([_task.priority isEqualToString:@"2"])
        [_segmentControl setSelectedSegmentIndex:1];
    
    else if([_task.priority isEqualToString:@"3"])
        [_segmentControl setSelectedSegmentIndex:2];
    
    if([_task.status isEqualToString:@"todo"])
        [_statusSegmentControl setSelectedSegmentIndex:0];
    
    else if([_task.status isEqualToString:@"inProgress"])
            [_statusSegmentControl setSelectedSegmentIndex:1];
    
    else if([_task.status isEqualToString:@"done"])
        [_statusSegmentControl setSelectedSegmentIndex:2];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   
}

- (IBAction)saveButtonAction:(id)sender {
    
    [confirmationAlertView show];
    
    NSString* taskName = _nameTextField.text;
    NSString* taskDescription = _descriptionTextField.text;
    
    if(![taskName isEqualToString:@""] && ![taskDescription isEqualToString:@""]){
        
        _task.taskName = taskName;
        _task.taskDescription = taskDescription;
        
        if(![_task.status isEqualToString:@"done"] && ![_task.status isEqualToString:@"inProgress"]){
            _task.status = [statuses objectAtIndex:[_statusSegmentControl selectedSegmentIndex]];
        }
        if([_task.status isEqualToString:@"inProgress"]){
            if([_statusSegmentControl selectedSegmentIndex]==2){
                _task.status = [statuses objectAtIndex:[_statusSegmentControl selectedSegmentIndex]];
            }
        }
    }
    
    _task.priority =[priorties objectAtIndex:[_segmentControl selectedSegmentIndex]];
    
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(alertView ==confirmationAlertView){
        if(buttonIndex==0){
            [self saveEditAction];
        }else{
            
        }
    }
}

-(void)saveEditAction{
    [self writeInUserDefaults];
}

-(void) writeInUserDefaults{
    NSString* taskKey=@"task";
    taskKey = [taskKey stringByAppendingString:[NSString stringWithFormat:@"%i",_task.taskId]];
    NSData* taskObjectData =[NSKeyedArchiver archivedDataWithRootObject:_task];
    [userDefaults2 setObject:taskObjectData forKey:taskKey];
    ViewController *detailsScreenView = [self.storyboard instantiateViewControllerWithIdentifier:@"mainScreen"];    
    [self presentViewController:detailsScreenView animated:YES completion:nil];
    
}



- (IBAction)cancelButtonAction:(id)sender {
    ViewController *detailsScreenView = [self.storyboard instantiateViewControllerWithIdentifier:@"mainScreen"];
    [self presentViewController:detailsScreenView animated:YES completion:nil];
}
@end
