//
//  ViewController+initializationCategory.m
//  TodoList
//
//  Created by Esraa Hassan on 3/23/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

#import "ViewController+initializationCategory.h"

@implementation ViewController (initializationCategory)
- (void)initializeTabBar{
    CGRect rect = CGRectMake(0, 30, self.tabBar.frame.size
                             .width, self.tabBar.frame.size
                             .height);
    self.tabBar.frame = rect;
    
    
    self.tabBar.delegate = self;
    //[self.tabBar setTintColor:[UIColor colorWithCIColor:[CIColor blueColor]]];
}
- (void)initializeTableView{
        
    self.tableViewController = [TableViewController new];
    self.tableViewController.mainScreen = self;
    
    [self.tableViewController readData];
    self.tableView.delegate = self.tableViewController;
    self.tableView.dataSource = self.tableViewController;
    
    
    
    
}

- (void)initialieSearchBar{
   // SearhBarController* searchBarController = [SearhBarController new];
    [self.todoSearchBar setDelegate:self];
}
@end
