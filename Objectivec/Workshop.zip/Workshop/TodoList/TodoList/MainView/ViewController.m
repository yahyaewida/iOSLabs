//
//  ViewController.m
//  TodoList
//
//  Created by Esraa Hassan on 3/22/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

#import "ViewController.h"
#import "Task.h"
#import "ViewController+initializationCategory.h"
#import"AddViewController.h"
@interface ViewController ()

@end

@implementation ViewController{
NSMutableArray *filteredArray;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initialize];
    
    
}
-(void) initialize{
    [self initializeTabBar];
    [self initializeTableView];
    [self initialieSearchBar];
}

-(void) tabChangedAction:(NSUInteger)indexOfTab{
    NSString* comparisonText=@"";
    [_tableViewController readData];
    
    if(indexOfTab ==0){
        _tableViewController.tabIndex = 0;
    }
    
    if(indexOfTab ==1){
        _tableViewController.tabIndex = 1;
        comparisonText=@"inProgress";
        [self filterOnStatus:comparisonText];
    }
    else if(indexOfTab == 2){
        _tableViewController.tabIndex = 2;
        comparisonText = @"done";
        [self filterOnStatus:comparisonText];
    }
    
    
    else if(indexOfTab ==3){
        _tableViewController.tabIndex = 3;
        NSSortDescriptor *filterDescriptor = [[NSSortDescriptor alloc] initWithKey:@"taskCreationDate" ascending:NO];
        
        _tableViewController.dataArray = [ _tableViewController.dataArray sortedArrayUsingDescriptors:@[filterDescriptor]];
        
        
    }
    else if(indexOfTab ==4){
        _tableViewController.tabIndex = 4;
        _tableViewController.medPriorityCount=0;
        _tableViewController.highPriorityCount=0;
        _tableViewController.lowPriorityCount=0;
        
        for(int i=0;i<_tableViewController.dataArray.count;i++){
            if([[(Task*)[_tableViewController.dataArray objectAtIndex:i]priority] isEqualToString:@"1"]){
                _tableViewController.lowPriorityCount++;
            }
            
            if([[(Task*)[_tableViewController.dataArray objectAtIndex:i]priority] isEqualToString:@"2"]){
                _tableViewController.medPriorityCount++;
            }
            
            if([[(Task*)[_tableViewController.dataArray objectAtIndex:i]priority] isEqualToString:@"3"]){
                _tableViewController.highPriorityCount++;
            }
            
        }
        NSSortDescriptor *filterDescriptor = [[NSSortDescriptor alloc] initWithKey:@"priority" ascending:NO];
        
        _tableViewController.dataArray = [ _tableViewController.dataArray sortedArrayUsingDescriptors:@[filterDescriptor]];
        
        
    }
    if(_tableViewController.dataArray.count>0 && indexOfTab!=3 && indexOfTab!=4){
        NSSortDescriptor *filterDescriptor = [[NSSortDescriptor alloc] initWithKey:@"priority" ascending:YES];
        
        NSSortDescriptor *filterDescriptor2 = [[NSSortDescriptor alloc] initWithKey:@"taskCreationDate" ascending:YES];
        
        _tableViewController.dataArray = [ _tableViewController.dataArray sortedArrayUsingDescriptors:@[filterDescriptor,filterDescriptor2]];
    }
    [_tableView reloadData];
}

- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item{
   NSUInteger indexOfTab = [[tabBar items] indexOfObject:item];
    [self tabChangedAction:indexOfTab];
  
}

-(void) filterOnStatus:(NSString*) comparisonText{

  NSMutableArray* newArray = [NSMutableArray new];

    for(int i=0;i<_tableViewController.dataArray.count;i++){
        if([[(Task*)[_tableViewController.dataArray objectAtIndex:i]status] isEqualToString:comparisonText]){
            [newArray addObject:[_tableViewController.dataArray objectAtIndex:i]];
        }
    }
    _tableViewController.dataArray = newArray;
    
}




- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController{
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)addTaskButtonAction:(id)sender {
    
    AddViewController *addScreenView = [self.storyboard instantiateViewControllerWithIdentifier:@"addScreen"];
    addScreenView.tableViewController = self;
    [self presentViewController:addScreenView animated:YES completion:nil];
}
- (void)updateTableView {
    [_tableViewController readData];
    [_tableView reloadData];
}



- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    if(searchText.length == 0){
        _tableViewController.isFiltered = NO;
        /*[_tableViewController readData];
        [_tableView reloadData];*/
        [self tabChangedAction:_tableViewController.tabIndex];
    }else{
        
        filteredArray = [NSMutableArray new];
        _tableViewController.isFiltered = YES;
        
        for(int i = 0; i < [_tableViewController.dataArray count]; i++){
            if([[[[_tableViewController.dataArray objectAtIndex:i] taskName]lowercaseString]containsString:[searchText lowercaseString]]){
                [filteredArray addObject:[_tableViewController.dataArray objectAtIndex:i]];
            }
        }
        self.tableViewController.dataArray = filteredArray;
        [self.tableView reloadData];
    }
   
}
- (void)openDetailsView:(Task*)task{
    DetailsViewController *detailsScreenView = [self.storyboard instantiateViewControllerWithIdentifier:@"detailsScreen"];
    
    detailsScreenView.task=task;
    [self presentViewController:detailsScreenView animated:YES completion:nil];
}


@end
