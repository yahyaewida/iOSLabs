//
//  ViewController+initializationCategory.h
//  TodoList
//
//  Created by Esraa Hassan on 3/23/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

#import "ViewController.h"
#import "UserDefaultsObject.h"
@interface ViewController (initializationCategory)
-(void) initializeTabBar;
-(void) initializeTableView;
-(void) initialieSearchBar;
@end
