//
//  ViewController.h
//  TodoList
//
//  Created by Esraa Hassan on 3/22/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TableViewController.h"
#import "OpenDetailsViewProtocol.h"
#import "TableViewUpdateProtocol.h"
#import "DetailsViewController.h"
@interface ViewController : UIViewController<TableViewUpdateProtocol,UITabBarDelegate,UISearchBarDelegate,UISearchBarDelegate,OpenDetailsViewProtocol>
@property (weak, nonatomic) IBOutlet UITableView *tableView;


@property (weak, nonatomic) IBOutlet UISearchBar *todoSearchBar;

@property (weak, nonatomic) IBOutlet UITabBar *tabBar;
- (IBAction)addTaskButtonAction:(id)sender;


@property TableViewController* tableViewController;
@end

