//
//  UserDefaultsObject.m
//  TodoList
//
//  Created by Esraa Hassan on 3/23/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

#import "UserDefaultsObject.h"

@implementation UserDefaultsObject

+ (NSUserDefaults *)getUserDefaults{
   
        defaults = [NSUserDefaults standardUserDefaults];
   
    return defaults;
}

@end
