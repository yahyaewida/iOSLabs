//
//  CommunicatorProtocol.h
//  NavigationControllerApp
//
//  Created by Esraa Hassan on 3/7/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol TableViewUpdateProtocol <NSObject>
- (void)updateTableView;

@end
