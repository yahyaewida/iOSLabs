//
//  AddViewController.h
//  TodoList
//
//  Created by Esraa Hassan on 3/23/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Task.h"
#import "TableViewUpdateProtocol.h"
@interface AddViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UITextField *descriptionTextField;

- (IBAction)backButtonAction:(id)sender;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentControl;
@property Task *task;
@property id<TableViewUpdateProtocol> tableViewController;
- (IBAction)addTaskAction:(id)sender;


@end
