//
//  AddViewController.m
//  TodoList
//
//  Created by Esraa Hassan on 3/23/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

#import "AddViewController.h"
#import "UserDefaultsObject.h"
@interface AddViewController ()

@end

@implementation AddViewController

NSString* priority;
NSString* name;
NSString* description;
NSArray* priorties;
NSUserDefaults *userDefaults2;
- (void)viewDidLoad {
    [super viewDidLoad];
    priorties = @[@"1",@"2",@"3"];
    priority=[priorties objectAtIndex:0];
    _task = [Task new];
    userDefaults2 = [UserDefaultsObject getUserDefaults];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}



- (IBAction)addTaskAction:(id)sender {

  
   if([self validateInput]){
        [self addTask];
        /*UIAlertView* view = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Added Successfully" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
        [view show];*/
       [self.tableViewController updateTableView];
       [self dismissViewControllerAnimated:YES completion:nil];
    }
    
    else{
        UIAlertView* view = [[UIAlertView alloc] initWithTitle:@"not valid data" message:@"please enter data first" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
        [view show];
    }
    
}

-(Boolean) validateInput{
    name = _nameTextField.text;
    description =_descriptionTextField.text;
    
    priority = [priorties objectAtIndex:_segmentControl.selectedSegmentIndex];


    if(![name isEqualToString:@""] && ![description isEqualToString:@""]){
        
        return YES;
    }
    return NO;

}
-(void) addTask{
     _task.taskName =name;
    _task.taskDescription = description;
    _task.priority = priority;
    _task.taskCreationDate = [NSDate date];
    _task.status=@"todo";
    [self writeInUserDefaults];
    
}

-(void) writeInUserDefaults{   
    NSInteger count = [self getNumberOfTasks] +1;
    _task.taskId = count;
    NSString* taskKey=@"task";
    taskKey = [taskKey stringByAppendingString:[NSString stringWithFormat:@"%li",(long)count]];
    NSData* taskObjectData =[NSKeyedArchiver archivedDataWithRootObject:_task];
    [userDefaults2 setObject:taskObjectData forKey:taskKey];
    [userDefaults2 setInteger:count forKey:@"count"];
    
    
}

-(NSInteger) getNumberOfTasks{
    return  [userDefaults2 integerForKey:@"count"];
}




- (IBAction)backButtonAction:(id)sender {
      [self dismissViewControllerAnimated:YES completion:nil];
}
@end
