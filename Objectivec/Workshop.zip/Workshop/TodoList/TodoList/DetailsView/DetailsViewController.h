//
//  DetailsViewController.h
//  TodoList
//
//  Created by Esraa Hassan on 3/23/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EditViewController.h"
#import "Task.h"
@interface DetailsViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *descriptionLabel;
@property (weak, nonatomic) IBOutlet UILabel *priorityLabel;
@property (weak, nonatomic) IBOutlet UILabel *dateOfCreationLabel;
@property (weak, nonatomic) IBOutlet UILabel *statusLabel;
@property (weak, nonatomic) IBOutlet UIImageView *priorityImageView;
- (IBAction)backButtonAction:(id)sender;
- (IBAction)editButtonAction:(id)sender;

@property Task *task;

@end
