//
//  DetailsViewController.m
//  TodoList
//
//  Created by Esraa Hassan on 3/23/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

#import "DetailsViewController.h"

@interface DetailsViewController ()

@end

@implementation DetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _nameLabel.text = _task.taskName;
    _descriptionLabel.text = _task.taskDescription;
    if([_task.priority isEqualToString:@"1"]){
        _priorityImageView.image = [UIImage imageNamed:@"lowPriority.jpg"];
        _priorityLabel.text = @"low";
    }
    if([_task.priority isEqualToString:@"2"]){
        _priorityImageView.image = [UIImage imageNamed:@"medPriority.png"];
        _priorityLabel.text = @"med";
    }
    if([_task.priority isEqualToString:@"3"]){
        _priorityImageView.image = [UIImage imageNamed:@"highPriority.jpg"];
        _priorityLabel.text = @"high";
    }
    _statusLabel.text = _task.status;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)backButtonAction:(id)sender {
   
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)editButtonAction:(id)sender {
    EditViewController *editScreenView = [self.storyboard instantiateViewControllerWithIdentifier:@"editScreen"];
    
    editScreenView.task = _task;
    UIWindow* keyWindow= [[UIApplication sharedApplication] keyWindow];
    [keyWindow addSubview: editScreenView.view];
    
    
    [self presentViewController:editScreenView animated:YES completion:nil];
    
   
    
}

@end
