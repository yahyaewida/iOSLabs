//
//  UserDefaultsObject.h
//  TodoList
//
//  Created by Esraa Hassan on 3/23/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

#import <Foundation/Foundation.h>



static NSUserDefaults *defaults =nil;
@interface UserDefaultsObject : NSObject


+(NSUserDefaults*) getUserDefaults;

@end
