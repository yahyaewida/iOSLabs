//
//  TableViewController.m
//  TodoList
//
//  Created by Esraa Hassan on 3/23/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

#import "TableViewController.h"
#import "UserDefaultsObject.h"
#import "DetailsViewController.h"

@interface TableViewController ()

@end

@implementation TableViewController
NSUserDefaults *userDefaults;
- (void)viewDidLoad {
    [super viewDidLoad];

}
-(void)readData{
    _dataArray = [NSMutableArray new];
    userDefaults = [UserDefaultsObject getUserDefaults];
    NSString* taskKey;
    NSInteger count = [self getNumberOfTasks];
    for(int i=1;i<= count ;i++){
        taskKey=@"task";
        taskKey = [taskKey stringByAppendingString:[NSString stringWithFormat:@"%i",i]];
        NSData* taskObjectData =[userDefaults objectForKey:taskKey];
        Task* task = [NSKeyedUnarchiver unarchiveObjectWithData:taskObjectData];
        if(task!=nil){
            if(_tabIndex==0){
                if([task.status isEqualToString:@"todo"]){
                    [_dataArray addObject:task];
                }
            }else{
                [_dataArray addObject:task];
            }
        }
    }
    NSSortDescriptor *filterDescriptor = [[NSSortDescriptor alloc] initWithKey:@"taskCreationDate" ascending:YES];
    _dataArray = [_dataArray sortedArrayUsingDescriptors:@[filterDescriptor]];

    
}

-(NSInteger) getNumberOfTasks{
    return  [userDefaults integerForKey:@"count"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    if(_tabIndex ==4 &&!_isFiltered)
        return 3;
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if(_tabIndex==4&&!_isFiltered){
        switch (section) {
            case 0:
                return _highPriorityCount;
                break;
            case 1:
                 return _medPriorityCount;
                break;
            case 2:
                return _lowPriorityCount;
                break;
            default:
                break;
        }
    }
    return _dataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 100;
}



- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    
    NSString* title=@"";
    if(_tabIndex == 4 && !_isFiltered){
        switch (section) {
            case 0:
                title=@"high";
                break;
                
            case 1:
                title=@"med";
                break;
            case 2:
                title=@"low";
                break;
        }
    }
    return title;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
  
    Task* task=nil;
    if(_tabIndex!=4 ||_isFiltered){
     task = (Task*)[_dataArray objectAtIndex:indexPath.row];
    }
    else{
        
    }
    printf("%li",(indexPath.section + indexPath.row));
    
    
      
        if(_tabIndex!=4 ||_isFiltered){
            cell.textLabel.text=[task taskName];
            cell.detailTextLabel.text=[task taskDescription];
            
            if([task.priority isEqualToString:@"1"]){
                cell.imageView.image = [UIImage imageNamed:@"lowPriority.jpg"];
            }
            else if([task.priority isEqualToString:@"2"]){
                cell.imageView.image = [UIImage imageNamed:@"medPriority.png"];
            }
            else if([task.priority isEqualToString:@"3"]){
                cell.imageView.image = [UIImage imageNamed:@"highPriority.jpg"];
            }
        }
        else{
            if (indexPath.section ==0){
                NSMutableArray * highArray =[NSMutableArray new];
                for(int i=0;i<_dataArray.count;i++){
                    task = (Task*)[_dataArray objectAtIndex:i];
                    if([task.priority isEqualToString:@"3"]){
                        [highArray addObject:[_dataArray objectAtIndex:i]];
                    }
                }
                if(highArray.count>0){
                    task = (Task*)[highArray objectAtIndex:indexPath.row];
                    cell.textLabel.text=[task taskName];
                    cell.detailTextLabel.text=[task taskDescription];
                    cell.imageView.image = [UIImage imageNamed:@"highPriority.jpg"];
                }
            }
                    
                else if (indexPath.section ==1){
                    NSMutableArray * medArray =[NSMutableArray new];
                    for(int i=0;i<_dataArray.count;i++){
                        task = (Task*)[_dataArray objectAtIndex:i];
                    if([task.priority isEqualToString:@"2"]){
                        [medArray addObject:[_dataArray objectAtIndex:i]];
                    }
                       
                    }
                    if(medArray.count >0){
                        task = (Task*)[medArray objectAtIndex:indexPath.row];
                        cell.textLabel.text=[task taskName];
                        cell.detailTextLabel.text=[task taskDescription];
                        cell.imageView.image = [UIImage imageNamed:@"medPriority.png"];
                    }
                    
                 }
               else if (indexPath.section ==2){
                   NSMutableArray * lowArray =[NSMutableArray new];
                   for(int i=0;i<_dataArray.count;i++){
                       task = (Task*)[_dataArray objectAtIndex:i];
                    if([task.priority isEqualToString:@"1"]){
                       [lowArray addObject:[_dataArray objectAtIndex:i]];
                    }
                      
                   }
                   if(lowArray.count>0){
                       task = (Task*)[lowArray objectAtIndex:indexPath.row];
                       cell.textLabel.text=[task taskName];
                       cell.detailTextLabel.text=[task taskDescription];
                       cell.imageView.image = [UIImage imageNamed:@"lowPriority.jpg"];
                   }
                }
                
        }
    
    
    return cell;
}



/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
       _dataArray =  [[NSMutableArray alloc]initWithArray:_dataArray];
        if(_tabIndex !=4){
            NSString* taskKey=@"task";
            
            int taskId = [(Task*)[_dataArray objectAtIndex:indexPath.row] taskId];
            
            taskKey = [taskKey stringByAppendingString:[NSString stringWithFormat:@"%i",taskId]];
            [self removeTaskFromUserDefaults:taskKey];
            [_dataArray removeObject:[_dataArray objectAtIndex:indexPath.row]];
            [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        }
        else{
            

            switch (indexPath.section) {
                case 0:
                    _highPriorityCount--;
                    break;
                case 1:
                    _medPriorityCount--;
                    break;
                case 2:
                    _lowPriorityCount--;
                    break;
                default:
                    break;
            }
            
            NSString* taskKey=@"task";
            
            int taskId = [(Task*)[_dataArray objectAtIndex:indexPath.row] taskId];
            
            taskKey = [taskKey stringByAppendingString:[NSString stringWithFormat:@"%i",taskId]];
            [self removeTaskFromUserDefaults:taskKey];
            
            [_dataArray removeObject:[_dataArray objectAtIndex:( indexPath.section + indexPath.row)]];
            printf("test%li\n",(indexPath.section + indexPath.row));
        }
        
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        
        [tableView reloadData];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
  
    Task *task = nil;
    if(_tabIndex==4){
        task = (Task*)[_dataArray objectAtIndex:(indexPath.row +indexPath.section)];
        
    }else{
        task = (Task*)[_dataArray objectAtIndex:indexPath.row];
    }
    [_mainScreen openDetailsView:task];
    
}

-(void) removeTaskFromUserDefaults:(NSString*)key{
    [userDefaults removeObjectForKey:key];
   // NSInteger count =[userDefaults integerForKey:@"count"] -1;
    //[userDefaults setInteger:count forKey:@"count"];
}


@end
