//
//  TableViewController.h
//  TodoList
//
//  Created by Esraa Hassan on 3/23/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Task.h"
#import "OpenDetailsViewProtocol.h"
@interface TableViewController : UITableViewController<UISearchBarDelegate,OpenDetailsViewProtocol>

@property id<OpenDetailsViewProtocol> mainScreen;
@property int medPriorityCount;
@property int highPriorityCount;
@property int lowPriorityCount;
@property NSMutableArray* dataArray;
-(void)readData;
@property BOOL isFiltered;

@property int tabIndex;
@end
