//
//  Colleague.m
//  ColleagueApp
//
//  Created by Esraa Hassan on 3/5/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

#import "Colleague.h"

@implementation Colleague

@end
