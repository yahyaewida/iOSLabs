//
//  InsertMovieProtocol.swift
//  MovieList
//
//  Created by Esraa Hassan on 3/25/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

import Foundation

protocol InsertMovieProtocol{
    
    func insertMovie(newMovie : Movie)
}
