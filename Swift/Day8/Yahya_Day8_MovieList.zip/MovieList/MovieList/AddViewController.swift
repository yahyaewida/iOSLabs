//
//  AddViewController.swift
//  MovieList
//
//  Created by Esraa Hassan on 3/25/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

import UIKit

class AddViewController: UIViewController ,UIImagePickerControllerDelegate, UINavigationControllerDelegate {

  
    
    @IBOutlet weak var ratingTextField: UITextField!
    @IBOutlet weak var titleTextField: UITextField!
    
    @IBOutlet weak var genreTextField: UITextField!
    @IBOutlet weak var releaseYearTextField: UITextField!
    
    @IBOutlet weak var movieImageView: UIImageView!
    var tableViewControllerReference : InsertMovieProtocol?
    var mTitle = "",mImage = "",rating = "", releaseYear = "" , genre = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
    }

    
    @IBAction func addButtonAction(_ sender: Any) {
        
        if validateInput() {
            let newMovie = Movie(mTitle: mTitle, mImage: mImage, mrating: Float(rating) ?? 0.0 , mReleaseYear: Int(releaseYear) ?? 2020 , mGenre: genre)
            tableViewControllerReference?.insertMovie(newMovie: newMovie,movieImage: movieImageView.image!);

            self.navigationController?.popViewController(animated: false)
       
        }else{
            let alert = UIAlertController(title: "Invalid Data", message: "Please enter all data before continue", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            
            self.present(alert, animated: true, completion: nil)
        }
      
    }
    
    func validateInput() -> Bool {
        mTitle = (titleTextField.text ?? "")
        rating = (ratingTextField.text ?? "")
        releaseYear = (releaseYearTextField.text ?? "")
        genre = (genreTextField.text ?? "")
        
        if mTitle == "" || rating == "" || releaseYear == "" || genre == "" || mImage == ""{
            return false
        }
        return true
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func selectImageButtonAction(_ sender: UIButton) {
        
         let imgPicker = UIImagePickerController()
         imgPicker.delegate = self
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary){
            imgPicker.sourceType = .photoLibrary
            imgPicker.allowsEditing = true
            self.present(imgPicker, animated: true, completion: nil)
        }
        else{
            print("cannot open photos")
        }
    }
   
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage{
         
            
            mImage = "SelectedImage"
           
            movieImageView.image = pickedImage
            
          
           
        }
     
        picker.dismiss(animated: true, completion: nil)
    }
}
