//
//  SQLHandler.swift
//  MovieList
//
//  Created by Esraa Hassan on 3/30/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

import Foundation
import SQLite3

class SQLHandler{
    
    private static var instance = SQLHandler()
    
    private let fileURL : URL? = try! FileManager.default
        .url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        .appendingPathComponent("dbFile.sqlite")
    
    private var db: OpaquePointer?
    
    private let createTableString = "CREATE TABLE IF NOT EXISTS movies(Name CHAR(255) PRIMARY KEY NOT NULL,ReleaseDate CHAR(255),Image text,genere CHAR(255),Rate REAL);"
    
    
   private let insertStatementString = "insert into movies VALUES (? , ? , ? , ? , ?);"
   private let queryStatementString = "SELECT * FROM movies ;"
   private  let updateStatementString = "UPDATE movies SET Name = ? , ReleaseDate = ? , Image = ? , Rate = ? , genere = ? WHERE Name = ?;"
   private let deleteStatementString = "DELETE FROM movies ;"
    
    static func getInstance() -> SQLHandler{
        return self.instance
    }
    
    
    
    
    private init(){
        db = self.openDatabase()
        self.createTable()
    }
   
    
    private func openDatabase() -> OpaquePointer? {
        let dbPath = fileURL?.path
        guard let dbPath2 = dbPath else {
            print("part1DbPath is nil.")
            return nil
        }
        if sqlite3_open(dbPath2, &db) == SQLITE_OK {
            print("Successfully opened connection to database at \(dbPath2)")
            
            return db
        } else {
            print("Unable to open database.")
        }
        return nil
    }
    
    
    private func createTable() {
        var createTableStatement: OpaquePointer?
        if sqlite3_prepare_v2(db, createTableString, -1, &createTableStatement, nil) ==
            SQLITE_OK {
            if sqlite3_step(createTableStatement) == SQLITE_DONE {                
            } else {
                print("movies table is not created.")
            }
        } else {
            print("CREATE TABLE statement is not prepared.")
        }
        sqlite3_finalize(createTableStatement)
    }
    
    func insert(name nameValue:String,rleaseDate releaseDateValue:String,imagePath imageValue:String,rate rateValue:Float , genere genereValue:String) {
        var insertStatement: OpaquePointer?
        if sqlite3_prepare_v2(db, insertStatementString, -1, &insertStatement, nil) ==
            SQLITE_OK {
            sqlite3_bind_text(insertStatement, 1, (nameValue as NSString).utf8String, -1, nil)
            sqlite3_bind_text(insertStatement, 2, (releaseDateValue as NSString).utf8String, -1, nil)
            sqlite3_bind_text(insertStatement, 3, (imageValue as NSString).utf8String, -1, nil)
            sqlite3_bind_text(insertStatement, 4, (genereValue as NSString).utf8String, -1, nil)
            sqlite3_bind_double(insertStatement, 5, Double(rateValue))
            
            if sqlite3_step(insertStatement) == SQLITE_DONE {
                print("\nSuccessfully inserted row.")
            } else {
                print("\nCould not insert row.")
            }
        } else {
            print("\nINSERT statement is not prepared.")
        }
        sqlite3_finalize(insertStatement)
    }
    
    
    
    func query() -> [Movie] {
        var queryStatement: OpaquePointer?
        var movies = [Movie]()
        if sqlite3_prepare_v2(
            db,
            queryStatementString,
            -1,
            &queryStatement,
            nil
            ) == SQLITE_OK {
           
            
            while (sqlite3_step(queryStatement) == SQLITE_ROW) {
                let rate = sqlite3_column_double(queryStatement, 4)
                guard let queryResultCol1 = sqlite3_column_text(queryStatement, 0) else {
                    print("Query result is nil.")
                    sqlite3_finalize(queryStatement)
                    return [Movie]()
                }
                guard let queryResultCol2 = sqlite3_column_text(queryStatement, 1) else {
                    print("Query result is nil.")
                    sqlite3_finalize(queryStatement)
                    return [Movie]()
                }
                guard let queryResultCol3 = sqlite3_column_text(queryStatement, 2) else {
                    print("Query result is nil.")
                    sqlite3_finalize(queryStatement)
                    return [Movie]()
                }
                guard let queryResultCol5 = sqlite3_column_text(queryStatement, 3) else {
                    print("Query result is nil.")
                    sqlite3_finalize(queryStatement)
                    return [Movie]()
                }
                
                let name = String(cString: queryResultCol1)
                let releaseDate = String(cString: queryResultCol2)
                let imagePath = String(cString: queryResultCol3)
                
                let genere = String(cString: queryResultCol5)
                movies.append(Movie(mTitle: name, mImage: imagePath, mrating: Float(rate), mReleaseYear: Int(releaseDate) ?? 2020, mGenre: genere))
                //print("\(name) | \(releaseDate)")
            }
        } else {
            let errorMessage = String(cString: sqlite3_errmsg(db))
            print("\nQuery is not prepared \(errorMessage)")
        }
        sqlite3_finalize(queryStatement)
        return movies
    }
    
    
    func update(name nameValue:String,rleaseDate releaseDateValue:String,imagePath imageValue:String,rate rateValue:Float ,genereValue genereValue:String) {
        var updateStatement: OpaquePointer?
        if sqlite3_prepare_v2(db, updateStatementString, -1, &updateStatement, nil) == SQLITE_OK {
            
            sqlite3_bind_text(updateStatement, 1, (nameValue as NSString).utf8String, -1, nil)
            sqlite3_bind_text(updateStatement, 2, (releaseDateValue as NSString).utf8String, -1, nil)
            sqlite3_bind_text(updateStatement, 3, (imageValue as NSString).utf8String, -1, nil)
            sqlite3_bind_double(updateStatement, 4, Double(rateValue))
            sqlite3_bind_text(updateStatement, 5, (genereValue as NSString).utf8String, -1, nil)
            sqlite3_bind_text(updateStatement, 6, (nameValue as NSString).utf8String, -1, nil)
            if sqlite3_step(updateStatement) == SQLITE_DONE {
                print("Successfully updated row.")
            } else {
                print("Could not update row.")
            }
        } else {
            print("UPDATE statement could not be prepared")
        }
        sqlite3_finalize(updateStatement)
    }
    
    func delete(name nameValue:String) {
        var deleteStatement: OpaquePointer?
        if sqlite3_prepare_v2(db, deleteStatementString, -1, &deleteStatement, nil) ==
            SQLITE_OK {
            //sqlite3_bind_text(deleteStatement, 1, (nameValue as NSString).utf8String, -1, nil)
            
            if sqlite3_step(deleteStatement) == SQLITE_DONE {
                print("Successfully deleted row.")
            } else {
                print("Could not delete row.")
            }
        } else {
            print("DELETE statement could not be prepared")
        }
        
        sqlite3_finalize(deleteStatement)
    }
    


    
}
