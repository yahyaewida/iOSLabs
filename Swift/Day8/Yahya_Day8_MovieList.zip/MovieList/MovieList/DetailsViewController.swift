//
//  ViewController.swift
//  MovieList
//
//  Created by Esraa Hassan on 3/25/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

import UIKit

class DetailsViewController: UIViewController {
    

    @IBOutlet weak var detailsScrollView: UIScrollView!
    
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var releaseYearLabel: UILabel!
    
    @IBOutlet weak var genreLabel: UILabel!
    
    @IBOutlet weak var movieImageView: UIImageView!
    
    var movie: Movie?
    var image:UIImage?

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        detailsScrollView.contentSize = CGSize(width: 100   , height:   100)
        nameLabel.text = movie!.title
        
        if movie!.image == "SelectedImage"{
            movieImageView.image = image!
        }else{
             movieImageView.image = UIImage(named: movie!.image)
        }

        
        genreLabel.text = movie!.genre
        
        releaseYearLabel.text = String(movie!.releaseYear)
       
    }

  
    
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }


}

