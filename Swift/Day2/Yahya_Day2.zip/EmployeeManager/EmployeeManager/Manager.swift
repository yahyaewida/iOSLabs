//
//  Manager.swift
//  EmployeeManager
//
//  Created by Esraa Hassan on 3/25/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

import Foundation

class Manager: Person {
    
    override init() {
        super.init()
    }
    override func getSalary() -> Double {
        return (super.getSalary() * 4);
    }
}
