//
//  Employee.swift
//  EmployeeManager
//
//  Created by Esraa Hassan on 3/24/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

import Foundation

class Employee: Person {
    
    override init() {
        super.init()
    }
    override func getSalary() -> Double {
        return (super.getSalary() * 2);
    }
    
}
