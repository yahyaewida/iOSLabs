//
//  Person.swift
//  EmployeeManager
//
//  Created by Esraa Hassan on 3/25/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

import Foundation

class Person{
    private var salary = 0.0
    
    func getSalary() -> Double {
        return salary;
    }
    
    func setSalary(salaryValue : Double) {
        if salaryValue > 0 {
            salary = salaryValue
        }
        else{
            salary=0
        }
    }
}
