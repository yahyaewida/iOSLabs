//
//  ViewController.swift
//  EmployeeManager
//
//  Created by Esraa Hassan on 3/25/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
   
    @IBOutlet weak var salaryTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    @IBAction func employeeButtonAction(_ sender: Any) {
        let employee = Employee()
        employee.setSalary(salaryValue: validateInputAndReturnValue())
        showAlert(title: "Salary", message:  "Employee Salary = " + String(employee.getSalary()))
       
    }
    
    @IBAction func managerButtonAction(_ sender: Any) {
        let manager = Manager()
        manager.setSalary(salaryValue: validateInputAndReturnValue())
        showAlert(title: "Salary", message:  "Manager Salary = " + String(manager.getSalary()))
    }
    
    func validateInputAndReturnValue() -> Double {
        if salaryTextField.text != "" {
            if( Double(salaryTextField.text!)! >= 0){
                return Double(salaryTextField.text!)!
            }else{
                showAlert(title: "Invalid data", message:  "Salary must be positive number")
                 salaryTextField.text = "0"
                return 0.0;
            }
        }
        showAlert(title: "Invalid Data", message:  "Please enter salary value")
        return 0.0
    }
    
    func showAlert(title : String , message : String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
    }
}

