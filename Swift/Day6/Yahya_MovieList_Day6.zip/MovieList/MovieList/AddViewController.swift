//
//  AddViewController.swift
//  MovieList
//
//  Created by Esraa Hassan on 3/25/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

import UIKit

class AddViewController: UIViewController {

    @IBOutlet weak var ratingTextField: UITextField!
    @IBOutlet weak var titleTextField: UITextField!
    
    @IBOutlet weak var genreTextField: UITextField!
    @IBOutlet weak var releaseYearTextField: UITextField!
    
    @IBOutlet weak var movieImageView: UIImageView!
    var tableViewControllerReference : InsertMovieProtocol?
    var mTitle = "",image = "babyDriver.jpg",rating = "", releaseYear = "" , genre = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        movieImageView.image = UIImage.init(named: image)
        
    }

    @IBAction func addButtonAction(_ sender: Any) {
        
        if validateInput() {
            let newMovie = Movie(mTitle: mTitle, mImage: image, mrating: Float(rating) ?? 0.0 , mReleaseYear: Int(releaseYear) ?? 2020 , mGenre: genre)
            tableViewControllerReference?.insertMovie(newMovie: newMovie);
            
            self.navigationController?.popViewController(animated: false)
         /*    let viewControllers: [UIViewController] = self.navigationController!.viewControllers as [UIViewController]
             self.navigationController!.popToViewController(viewControllers[viewControllers.count - 3], animated: true)*/
            
            showAddedAlert(movieTitle: mTitle)
        
        }else{
            let alert = UIAlertController(title: "Invalid Data", message: "Please enter all data before continue", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            
            self.present(alert, animated: true, completion: nil)
        }
      
    }
    
    func validateInput() -> Bool {
        mTitle = (titleTextField.text ?? "")
        rating = (ratingTextField.text ?? "")
        releaseYear = (releaseYearTextField.text ?? "")
        genre = (genreTextField.text ?? "")
        
        if mTitle == "" || rating == "" || releaseYear == "" || genre == "" {
            return false
        }
        return true
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    func showAddedAlert(movieTitle:String){
        let alert = UIAlertController(title: "Info", message: "Movie"+movieTitle+" added successfully", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
        
        
    }
    

}
