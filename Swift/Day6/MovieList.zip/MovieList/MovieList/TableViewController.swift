//
//  TableViewController.swift
//  MovieList
//
//  Created by Esraa Hassan on 3/25/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

import UIKit
import Kingfisher
import CoreData
class TableViewController: UITableViewController ,
InsertMovieProtocol {

    var isNetworkConnected = false
    
    var movies: [NSManagedObject] = []
    var remoteMoviesFromCache: [NSManagedObject] = []
    func insertMovie(newMovie : Movie,managedObject managedObjectValue:NSManagedObject){
        movies.append(managedObjectValue)
        moviesArray.append(newMovie)
        self.tableView.reloadData()
        
    }
    
    
     var moviesArray :[Movie] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //initializeMovies()
        
        
        if Reachability.Connection() {
            isNetworkConnected = true
            initializeJsonMovies()
        }else{
            isNetworkConnected = false
            remoteMoviesFromCache = CoreDataHandler.getCoreHandlerInstance().getWebserviceMovies()
        }
        
        var insertButton = UIBarButtonItem.init(title: "Add", style: UIBarButtonItemStyle.plain, target: self, action: Selector("addButtonAction"))
        self.navigationItem.setRightBarButton(insertButton, animated: true)


        
    
        movies = CoreDataHandler.getCoreHandlerInstance().getLocalMovies()
        
      
    }
   
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        if (editingStyle == .delete) {
            switch indexPath.section{
            case 0:
                
                CoreDataHandler.getCoreHandlerInstance().deleteFromEntity(entityName: "LocalMovies", object: movies[indexPath.row])
                movies.remove(at: indexPath.row)
            case 1:
                CoreDataHandler.getCoreHandlerInstance().deleteFromEntity(entityName: "RemoteMovies", object: remoteMoviesFromCache[indexPath.row])
                remoteMoviesFromCache.remove(at: indexPath.row)
            default:
                break
            }
            tableView.deleteRows(at: [indexPath], with: UITableViewRowAnimation.left)
            tableView.reloadData()
        }
        
    }
    @objc  func addButtonAction(){
        let addView = self.storyboard?.instantiateViewController(withIdentifier: "addScreen") as! AddViewController
        
        addView.tableViewControllerReference = self
        
        
        self.navigationController?.pushViewController(addView, animated: true)
        
        
    }
    
    func initializeMovies() {
        
        moviesArray.append(Movie(mTitle: "fast & furious 9", mImage: "ff9.jpg", mrating: 9.2, mReleaseYear: 2020, mGenre: "Action"))
        
        moviesArray.append(Movie(mTitle: "1917", mImage: "1917.jpg", mrating: 8.7, mReleaseYear: 2019, mGenre: "war / drama"))
        
        moviesArray.append(Movie(mTitle: "ford v ferrari", mImage: "fordvferrari.png", mrating: 9.3, mReleaseYear: 2019, mGenre: "sport / drama"))
        
        moviesArray.append(Movie(mTitle: "Inception", mImage: "inception.png", mrating: 8.8, mReleaseYear: 2010, mGenre: "Thriller / Sci-fic"))
        
        moviesArray.append(Movie(mTitle: "Avengers end-game", mImage: "avengers.jpg", mrating: 8.8, mReleaseYear: 2019, mGenre: "Action / Sci-fic"))
    }
   
   
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        switch indexPath.section {
        case 0:
            cell.titleLabel.text = movies[indexPath.row].value(forKey: "title") as! String
            cell.releaseYearLabel.text = String(movies[indexPath.row].value(forKey: "releaseYear") as! Int)

            let decodedData:NSData = NSData(base64Encoded: movies[indexPath.row].value(forKey: "imagePath") as! String ,options: .ignoreUnknownCharacters)!
            
            cell.movieImageView.image = UIImage(data: decodedData as Data)!
                
            
        case 1:
            cell.titleLabel.text = remoteMoviesFromCache[indexPath.row].value(forKey: "title") as! String
            
            cell.releaseYearLabel.text = String(remoteMoviesFromCache[indexPath.row].value(forKey: "releaseYear") as! Int)
            if isNetworkConnected{
                cell.movieImageView.kf.setImage(with: URL(string: remoteMoviesFromCache[indexPath.row].value(forKey: "imagePath") as! String ))
                if indexPath.row == 0{
                    print("data from network")
                }
            }else{
               //cell.movieImageView.kf.setImage(with: URL(string: remoteMoviesFromCache[indexPath.row].value(forKey: "imagePath") as! String ))
                cell.movieImageView.image = UIImage(named: "avengers.jpg")
                if indexPath.row == 0{
                    print("data from localCache")
                }
            }
        default:
            break
        }
        
        return cell;
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 2;
    }
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0:
            return "local"
        case 1: return "Remote"
        default:
            return "local"
        }
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return movies.count
        case 1:
           return remoteMoviesFromCache.count
            
        default:
            break
        }
        return moviesArray.count;
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailsView = self.storyboard?.instantiateViewController(withIdentifier: "detailsScreen") as! DetailsViewController
        
        var movieObject :NSManagedObject?
        switch indexPath.section {
        case 0:
             movieObject = movies[indexPath.row]
            detailsView.isLocalImage = true
            
        case 1:
            movieObject = remoteMoviesFromCache[indexPath.row]
            detailsView.isLocalImage = false
        default:
            break
        }
         detailsView.movie = Movie(mTitle: movieObject?.value(forKey: "title") as! String, mImage: movieObject?.value(forKey: "imagePath") as! String, mrating: movieObject?.value(forKey: "rating") as! Float, mReleaseYear: movieObject?.value(forKey: "releaseYear") as! Int, mGenre: movieObject?.value(forKey: "genre") as! String)

        self.navigationController?.pushViewController(detailsView, animated: true)
        
    }
    
    
}
