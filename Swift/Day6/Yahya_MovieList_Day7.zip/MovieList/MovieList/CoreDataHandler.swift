//
//  CoreDataHandler.swift
//  MovieListNetwork
//
//  Created by Esraa Hassan on 4/1/20.
//  Copyright © 2020 Yahya. All rights reserved.
//
import UIKit
import Foundation
import CoreData
class CoreDataHandler{
    private let appDelegate = UIApplication.shared.delegate as! AppDelegate
    private  var managedContext:NSManagedObjectContext?
    private static var instance = CoreDataHandler()
    public init () {
         managedContext = appDelegate.persistentContainer.viewContext
        //print("test3")
    }
    
    static func getCoreHandlerInstance() -> CoreDataHandler {
        
        return instance
    }
    func getManagedContext() -> NSManagedObjectContext {
        return managedContext!
    }
    
     func insertInLocalMovies(movie movieValue:Movie) -> NSManagedObject {
        let entity = NSEntityDescription.entity(forEntityName: "LocalMovies", in: managedContext!)
        
        let movie = NSManagedObject(entity: entity!, insertInto: managedContext!)
        
        movie.setValue(movieValue.title, forKey: "title")
        movie.setValue(movieValue.image, forKey: "imagePath")
        movie.setValue(movieValue.genre, forKey: "genre")
        movie.setValue(movieValue.rating, forKey: "rating")
        movie.setValue(movieValue.releaseYear, forKey: "releaseYear")
        
        do{
            try managedContext!.save()
        }
        catch{
            print("error in insertInLocalMovies")
        }
        return movie
    }
    
     func getLocalMovies() -> Array<NSManagedObject> {
        var localMovies = Array<NSManagedObject>()
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "LocalMovies")
        
        do{
            localMovies = try managedContext!.fetch(fetchRequest)
            
        }
        catch{
            print("error in getLocalMovies")
        }

        return localMovies
    }
    
    func getWebserviceMovies() -> Array<NSManagedObject> {
        
        
        var localMovies = Array<NSManagedObject>()
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "RemoteMovies")
        
        do{
            localMovies = try managedContext!.fetch(fetchRequest)
        }
        catch{
            print("error in getWebserviceMovies")
        }
        
        
        
        return localMovies
    }
    
    func insertInWebserviceMovies(arrayOfMovies:[Movie]) {
        let entity = NSEntityDescription.entity(forEntityName: "RemoteMovies", in: managedContext!)
        clearWebserviceMovies()
        for index in 0...arrayOfMovies.count-1 {
            
            
            let movieValue = arrayOfMovies[index]
            let movie = NSManagedObject(entity: entity!, insertInto: managedContext!)
            movie.setValue(movieValue.title, forKey: "title")
            movie.setValue(movieValue.image, forKey: "imagePath")
            movie.setValue(movieValue.genre, forKey: "genre")
            movie.setValue(movieValue.rating, forKey: "rating")
            movie.setValue(movieValue.releaseYear, forKey: "releaseYear")
            
            //managedContext?.delete(movie)
            do{
                try managedContext!.save()
            }
            catch{
                print("error in insertInWebserviceMovies")
            }
        }
    }
    
    func clearWebserviceMovies(){
        var localMovies = Array<NSManagedObject>()
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "RemoteMovies")
        
        do{
            localMovies = try managedContext!.fetch(fetchRequest)
            
            for index in 0...localMovies.count-1 {
                managedContext?.delete(localMovies[index])
            }
            
        }
        catch{
            print("error in clearWebserviceMovies")
        }
            
    
    }
    func deleteFromEntity(entityName name:String , object value:NSManagedObject){
        managedContext?.delete(value)
        
        do{
            try managedContext!.save()
        }
        catch{
            print("error in deleteFromEntity")
        }
    }
    func clearLocalMovies(){
        var localMovies = Array<NSManagedObject>()
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "LocalMovies")
        
        do{
            localMovies = try managedContext!.fetch(fetchRequest)
            
            for index in 0...localMovies.count-1 {
                managedContext?.delete(localMovies[index])
            }
            
        }
        catch{
            print("error in clearWebserviceMovies")
        }
        
        
    }
       
    
    
    
}
