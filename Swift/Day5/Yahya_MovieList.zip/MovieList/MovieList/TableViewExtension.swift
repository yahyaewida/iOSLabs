//
//  TableViewExtension.swift
//  MovieList
//
//  Created by Esraa Hassan on 3/26/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

import UIKit

extension AddViewController{
    
    func showAddedAlert(movieTitle:String){
        let alert = UIAlertController(title: "Info", message: "Movie"+movieTitle+" added successfully", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
        
        //print(movieTitle+" added")
    }
    
}
