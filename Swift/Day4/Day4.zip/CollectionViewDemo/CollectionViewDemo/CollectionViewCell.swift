//
//  CollectionViewCell.swift
//  CollectionViewDemo
//
//  Created by Esraa Hassan on 3/29/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

import UIKit


class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var cellImageView: UIImageView!
    
}
