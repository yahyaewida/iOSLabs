//
//  Friend.swift
//  FriendCustomCellApp
//
//  Created by Esraa Hassan on 3/29/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

import Foundation

struct Friend {
    var name : String
    var age : Int
    var imageName : String
}
