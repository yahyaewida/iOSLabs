//
//  ViewController.swift
//  FriendCustomCellApp
//
//  Created by Esraa Hassan on 3/29/20.
//  Copyright © 2020 Yahya. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    
    var tableViewController = TableViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableViewController.friendsArray = [Friend(name: "Yahya", age: 24,                  imageName: "males1.png"),
                                            Friend(name: "Ibrahim", age: 24, imageName: "males2.png"),
                                            Friend(name: "Rodayna", age: 7, imageName: "females1.png"),
                                            Friend(name: "Abdallah", age: 15, imageName: "males1.png"),
                                            Friend(name: "Hoda", age: 20, imageName: "females2.png")]
        tableView.delegate = tableViewController
        tableView.dataSource = tableViewController
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
      
    }


}

